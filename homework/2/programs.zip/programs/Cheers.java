// Prints a crowd cheering output.
public class Cheers {
    public static void main(String[] args) {
   	    // Complete the program code here:
    }
}
