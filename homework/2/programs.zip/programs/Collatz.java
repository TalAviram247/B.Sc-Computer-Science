// Demonstrates the Collatz conjecture. */
public class Collatz {
	public static void main(String args[]) {
	    // Complete the program code here:
	}
}
