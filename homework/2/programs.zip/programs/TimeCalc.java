
/** Performs time calculations. 
 */
public class TimeCalc {

	public static void main(String[] args) {
		// Concatenates the empty string "" with the left hour-digit, concatenates the
		// resulting string with the right hour-digit, then casts the resulting string as an int.
		int hours = Integer.parseInt("" + args[0].charAt(0) + args[0].charAt(1));
		// Does the same with the minute digits.
		int minutes = Integer.parseInt("" + args[0].charAt(3) + args[0].charAt(4));
		// Complete the program code here:
	}
}
