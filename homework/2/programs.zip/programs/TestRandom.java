/* Tests the "quality" of Java's Math.random function.
*/
public  class  TestRandom {
	static int a = 0;
	public static void main(String[]  args) {
		// Complete the program code here:
	}
}
