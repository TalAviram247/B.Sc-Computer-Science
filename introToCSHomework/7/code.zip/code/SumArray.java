class SumArray {

    public static void main(String args[]) {
        // Put your testing here. For example:
        int a[] = { 1, 2, 3, 4 };
        System.out.println(sumArr(a));
    }

    // Returns the sum of the elements in the given array.
    public static int sumArr(int arr[]) { 
        // Replace the following statement with your code:
        return 0;
    }
  
    // Returns the sum of the elements in the given array, up to, and including, element n.
    // Assumes that n is nonnegative.
    private static int sumArr(int arr[], int n) {
        // Replace the following statement with your code:
        return 0;
    } 
} 